const express=require("express");
const {getNotes,createNote,getNotebyId,deleteNote,updateNote}=require("../controllers/noteControllers");
const router=express.Router();
router.route('/').get(getNotes);
router.route('/create').post(createNote);
router.route('/:id').get(getNotebyId).delete(deleteNote).put(updateNote)
module.exports=router;