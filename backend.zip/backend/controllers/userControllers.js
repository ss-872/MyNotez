const asyncHandler = require('express-async-handler');
const User = require('../models/usersModel');
const registerUser=asyncHandler(async (req,res)=> {
    const {name,email,password,pic}=req.body
    console.log({name})
    console.log({email,password})
    const userExists=await User.findOne({email});
    if (userExists)
    {
        console.log("User Exists")
    }
    const user=User.create({
        name,email,password,pic
    })
    if (user)
    {
        console.log("Success")
        res.json({
            _id:user._id,
            name:user.name,
            email:user.email,
            isAdmin: user.isAdmin,
            pic: user.pic,
            
        })
    }
    else{
        console.log("Error occurred");
    }
    res.json({
        name,email
    });
});
const authUser=asyncHandler(async(req,res)=>{
    const {email,password}=req.body;
    const userExists=await User.findOne({email});
    if (userExists && (await userExists.matchPassword(password))){
        res.json({
            _id:user._id,
            name:user.name,
            email:user.email,
            isAdmin: user.isAdmin,
            pic: user.pic,
            token: generateToken(user._id),
        })
    }
    else{
        console.log("Invalid email or password");
    }
})
module.exports={registerUser,authUser};